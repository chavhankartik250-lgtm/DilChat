DilChat AI — Android Studio project
===================================

Yeh Android app ka source project hai (ready-made APK nahi). Ismein DM-inspired dark chat UI, supplied fictional avatar, message input/keyboard, aur offline demo replies hain. Header ke icons jaan-boojhkar inactive rakhe gaye hain.

Zaroori sachchai:
- Abhi replies local rule-based demo hain; yeh full AI model nahi hai.
- Internet-based natural AI replies ke liye ek AI API aur secure backend connect karna hoga. API key ko APK ke andar rakhna safe nahi hota.
- Offline mode mein sirf built-in demo replies milenge.
- Character fictional AI ke roop mein label ki gayi hai; UI Instagram/WhatsApp ka exact clone ya asli chat proof nahi hai.

APK banane ke liye:
1. Computer par Android Studio install karo.
2. Android Studio > Open > is extracted DilChat folder ko select karo.
3. Gradle sync complete hone do (internet required for first build).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio APK ka location dikhayega; apne phone par transfer karke install kar sakte ho.

Requirements: Android Studio supporting Android Gradle Plugin 8.7.3, JDK 17, Android SDK 35.
