package com.example.dilchat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DilChatScreen() }
    }
}

data class ChatMessage(val text: String, val fromMe: Boolean, val time: String = "now")

private val bg = Color(0xFF08090D)
private val panel = Color(0xFF17181D)
private val muted = Color(0xFF9698A3)
private val pink = Color(0xFFD946EF)

@Composable
fun DilChatScreen() {
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hii 😊 kya kar raha hai?", false, "5:51 PM"),
            ChatMessage("Bas aise hi, tu bata", true, "5:52 PM"),
            ChatMessage("Main bhi chill kar rahi hu 😂 aaj ka din kaisa tha tera?", false, "5:52 PM")
        )
    }
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().background(bg)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 7.dp, end = 5.dp, top = 8.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
                    Image(painterResource(R.drawable.avatar), contentDescription = "Fictional AI avatar", modifier = Modifier.size(43.dp).clip(CircleShape))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Aarohi 💖", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text("AI character · fictional", color = muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { }) { Icon(Icons.Filled.EmojiEmotions, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.Call, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.Videocam, null, tint = Color.White, modifier = Modifier.size(27.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF25262C)))
                Column(Modifier.weight(1f).fillMaxWidth()) {
                    Spacer(Modifier.height(16.dp))
                    Text("TODAY", color = muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        state = listState,
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        items(messages) { msg ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromMe) Arrangement.End else Arrangement.Start) {
                                if (!msg.fromMe) {
                                    Image(painterResource(R.drawable.avatar), null, modifier = Modifier.padding(end = 7.dp, top = 14.dp).size(25.dp).clip(CircleShape))
                                }
                                Column(horizontalAlignment = if (msg.fromMe) Alignment.End else Alignment.Start, modifier = Modifier.widthIn(max = 290.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(if (msg.fromMe) Brush.linearGradient(listOf(Color(0xFF8338EC), Color(0xFFD946EF))) else Brush.linearGradient(listOf(Color(0xFF26272D), Color(0xFF26272D))))
                                            .padding(horizontal = 14.dp, vertical = 10.dp)
                                    ) { Text(msg.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp) }
                                    Text(msg.time, color = muted, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp, start = 5.dp, end = 5.dp))
                                }
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xFF222328)).padding(horizontal = 7.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { }) { Icon(Icons.Filled.CameraAlt, null, tint = pink, modifier = Modifier.size(25.dp)) }
                    BasicTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 7.dp),
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { sendMessage(draft, messages); draft = ""; scope.launch { listState.animateScrollToItem(messages.lastIndex) } }),
                        decorationBox = { inner -> Box { if (draft.isEmpty()) Text("Message…", color = Color(0xFF9B9CA4), fontSize = 16.sp); inner() } }
                    )
                    IconButton(onClick = { }) { Icon(Icons.Filled.Mic, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.Photo, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.EmojiEmotions, null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                    IconButton(onClick = { }) { Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
                }
                Text("Offline demo · replies are generated locally", color = Color(0xFF676975), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 5.dp))
            }
        }
    }
}

private fun sendMessage(raw: String, messages: MutableList<ChatMessage>) {
    val text = raw.trim()
    if (text.isEmpty()) return
    messages.add(ChatMessage(text, true))
    messages.add(ChatMessage(localReply(text), false))
}

private fun localReply(input: String): String {
    val s = input.lowercase()
    val replies = when {
        listOf("hi", "hello", "hii", "hey", "hlo").any { s.contains(it) } -> listOf("Hiii 😊 kya scene hai?", "Arey hii 😂 bata, kya chal raha hai?", "Hellooo 💗 main yahin hu, bol na")
        listOf("kaise ho", "kasi ahes", "kashi ahes", "how are you", "kaisi ho").any { s.contains(it) } -> listOf("Main mast hu 😊 tu kaisa hai?", "Ekdam theek 😌 tu suna, sab badhiya?", "Mi mast aahe 😄 tu kasa ahes?")
        listOf("college", "clg", "school", "lecture").any { s.contains(it) } -> listOf("Aaj college mein kya hua phir? 😄", "Oho 😂 lecture boring tha ya doston ne mood bana diya?", "Samajh sakti hu yaar, kabhi kabhi college full tiring hota hai")
        listOf("sad", "dukhi", "bura lag", "tension", "pareshan").any { s.contains(it) } -> listOf("Arey yaar 🥺 kya hua? Aaram se bata, sun rahi hu.", "Oh no 💗 aaj kuch bura hua kya? Main sun sakti hu.", "Kabhi kabhi aisa feel hota hai. Kya baat hai?")
        listOf("love", "miss you", "yaad", "pyaar").any { s.contains(it) } -> listOf("Awww 😊 tu bada filmy hai 😂", "Hehe 💗 achha ji, aur bata kya kar raha tha?", "Areee 😭😂 cute baat bol di tune")
        listOf("khana", "khaya", "jevlis", "jevan", "food", "poha").any { s.contains(it) } -> listOf("Achhaaa 😋 aur kya khaya?", "Wahh 😂 mujhe bhi bhookh yaad dila di", "Barobar 😄 paani bhi pi lena haan")
        listOf("marathi", "मराठी", "kay kartoy", "kasa ahes").any { s.contains(it) } -> listOf("Mi ithech aahe 😄 sang na, kay chalu aahe?", "Arey mast 😂 mag pudhe kay zala?", "Ho na 😊 tu sang, mi aiktey")
        s.endsWith("?") -> listOf("Hmm, majha vichar asa aahe ki situation var depend karta 😊", "Achha sawaal hai 😂 tu kya sochta hai?", "Mujhe lagta hai ho sakta hai, par thoda context bata na")
        else -> listOf("Achhaaa 😂 phir kya hua?", "Hmmm samajh gayi 😊 aur bata, phir?", "Arey sahi 😄 sunke achha laga", "Oho 😂 ye toh interesting hai!", "Achha baba 😌 tu bol, main sun rahi hu", "Hehe 😄 waise aaj aur kya kiya?")
    }
    return replies[(input.length + input.count { it == ' ' }) % replies.size]
}
